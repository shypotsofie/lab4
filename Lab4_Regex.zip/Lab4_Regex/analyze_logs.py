from collections import Counter
from pathlib import Path
import re

LOG_PATTERN = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2}) "
    r"(?P<time>\d{2}:\d{2}:\d{2}) "
    r"(?P<level>INFO|WARN|ERROR) "
    r"user=(?P<user>[\w.-]+|-) "
    r"ip=(?P<ip>(?:\d{1,3}\.){3}\d{1,3}) "
    r"method=(?P<method>GET|POST|PUT|DELETE) "
    r"path=(?P<path>\S+) "
    r"status=(?P<status>\d{3}) "
    r"duration=(?P<duration>\d+)ms$"
)


def parse_line(line: str) -> dict | None:
    match = LOG_PATTERN.fullmatch(line.strip())
    if not match:
        return None
    item = match.groupdict()
    item["status"] = int(item["status"])
    item["duration"] = int(item["duration"])
    return item


def main() -> None:
    log_path = Path("data/app.log")
    lines = log_path.read_text(encoding="utf-8").splitlines()

    records = []
    invalid_lines = []

    for number, line in enumerate(lines, start=1):
        record = parse_line(line)
        if record is None:
            invalid_lines.append((number, line))
        else:
            records.append(record)

    levels = Counter(item["level"] for item in records)
    methods = Counter(item["method"] for item in records)
    users = Counter(item["user"] for item in records if item["user"] != "-")

    errors = [item for item in records if item["level"] == "ERROR"]
    slow = [item for item in records if item["duration"] >= 300]

    print(f"Parsed records: {len(records)}")
    print(f"Invalid lines: {len(invalid_lines)}")
    print(f"Levels: {dict(levels)}")
    print(f"Methods: {dict(methods)}")
    print(f"Users: {dict(users)}")

    print("\nERROR records:")
    for item in errors:
        print(
            f"  {item['time']} user={item['user']} "
            f"status={item['status']} path={item['path']}"
        )

    print("\nSlow requests (>= 300 ms):")
    for item in slow:
        print(
            f"  {item['duration']} ms | {item['method']} "
            f"{item['path']} | user={item['user']}"
        )

    # Самостійна модифікація (Розділ 13)
    statuses = Counter(item["status"] for item in records)
    print(f"\nStatuses: {dict(statuses)}")

    bad_statuses = [item for item in records if item["status"] >= 400]
    print("\nRecords with status >= 400:")
    for item in bad_statuses:
        print(
            f"  {item['time']} status={item['status']} "
            f"{item['method']} {item['path']}"
        )

    id_path_pattern = re.compile(r"^/api/[A-Za-z_-]+/\d+$")
    paths_with_id = sorted({
        item["path"] for item in records if id_path_pattern.fullmatch(item["path"])
    })
    print("\nUnique paths with numeric ID:")
    for path in paths_with_id:
        print(f"  {path}")

    if invalid_lines:
        print("\nInvalid lines:")
        for number, text in invalid_lines:
            print(f"  Line {number}: {text}")


if __name__ == "__main__":
    main()